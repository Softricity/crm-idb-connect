// src/partners/partners.module.ts
import { Module } from '@nestjs/common';
import { PartnersService } from './partners.service';
import { PartnersController } from './partners.controller';
import { PrismaService } from '../prisma/prisma.service';

@Module({
  controllers: [PartnersController],
  providers: [PartnersService, PrismaService],
  exports: [PartnersService], // <-- Export the service
})
export class PartnersModule {}