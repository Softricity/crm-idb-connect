// src/partners/dto/bulk-delete.dto.ts
export class BulkDeletePartnerDto {
  partnerIds: string[];
}