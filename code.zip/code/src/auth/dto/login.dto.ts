// src/auth/dto/login.dto.ts
export class LoginDto {
  email: string;
  password: string;
}