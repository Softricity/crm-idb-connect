export enum Role {
  Admin = 'admin',
  Counsellor = 'counsellor',
  Agent = 'agent',
}