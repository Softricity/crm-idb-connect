// src/notes/dto/create-note.dto.ts
export class CreateNoteDto {
  text: string;
  lead_id: string;
}