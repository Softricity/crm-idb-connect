// src/notes/dto/update-note.dto.ts
export class UpdateNoteDto {
  text: string;
}