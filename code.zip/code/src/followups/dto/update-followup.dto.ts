// src/followups/dto/update-followup.dto.ts
export class UpdateFollowupDto {
  title?: string;
  due_date?: Date;
  completed?: boolean;
}