// src/followups/dto/update-comment.dto.ts
export class UpdateFollowupCommentDto {
  text: string;
}