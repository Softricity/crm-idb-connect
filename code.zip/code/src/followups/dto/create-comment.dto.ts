// src/followups/dto/create-comment.dto.ts
export class CreateFollowupCommentDto {
  text: string;
}